#include <iostream>             // cout, cerr
#include <cstdlib>              // EXIT_FAILURE
#include <GL/glew.h>            // GLEW library
#include <GLFW/glfw3.h>         // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> // Camera class
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" // library for images and textures

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "module 04"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo[2];         // Handle for the vertex buffer object
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Triangle mesh data
    GLMesh gMesh;  // cylinder
    GLMesh gMesh2; // cube
    GLMesh gMesh3; // vase

    // Shader program
    GLuint gProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 1.5f, 3.0f));

    // lasto mouse position
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;

    // true if first time click
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;


    GLuint gTextureId;  // texture wood
    GLuint gTextureId2; // texture jar
    GLuint gTextureId3; // texture floor

    // light colors
    glm::vec3 gLightColor1(0.7f, 0.8f, 0.6f); 
    glm::vec3 gLightColor2(0.4f, 0.6f, 0.9f); 

    // Light position 
    glm::vec4 gLightPosition1(0.0f, 4.0f, 5.0f, 1.0f); // first light
    glm::vec4 gLightPosition2(0.0f, 4.0f, -5.0f, 1.0f); // second light

    // lights rotation algne
    float gAngle = 0.0f;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char*[], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateCylinder(GLMesh &mesh);
void UCreateVase(GLMesh& mesh);
void UCreateCube(GLMesh& mesh);
void UDestroyMesh(GLMesh &mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId);
void UDestroyShaderProgram(GLuint programId);
bool UCreateTexture(const char* filename, GLuint& textureId); // (**)


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId) // (**)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        // generating texture object
        glGenTextures(1, &textureId);

        // make it current
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // uploading depending on the number of channels
        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        // using mipmapping
        glGenerateMipmap(GL_TEXTURE_2D);

        // releasing mem
        stbi_image_free(image);

        // unbind texture
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void CreateCylinder(int numSteps,
    float height,
    float radius,
    float textureRepeat,
    vector<glm::vec3>& v,
    vector<glm::vec3>& n,
    vector<glm::vec2>& t,
    vector<unsigned short>& indices)
{
    // half length
    float hl = height / 2.0f;

    // angle
    float a = 0.0f;

    // angle step
    float step = 360.0 / (float)numSteps;

     // dividing 360 degrees into numSteps
    for (int i = 0; i <= numSteps; i++)
    {
        // plint on circle x,y
        float x = cos(glm::radians(a)) * radius;
        float z = sin(glm::radians(a)) * radius;

        // computing normal
        glm::vec3 normal = glm::vec3(-x / radius, 0, -z / radius);

        // first texture coordinate
        float texCoordU = (float)i / (float)numSteps;

        int j = v.size();

        // First triangle
        v.push_back(glm::vec3(x, hl, z));
        n.push_back(normal);
        t.push_back(glm::vec2(texCoordU, 1));

        // second triangle
        v.push_back(glm::vec3(x, -hl, z));
        n.push_back(normal);
        t.push_back(glm::vec2(texCoordU, 0));

        // creating indices array
        if (i < numSteps)
        {
            indices.push_back(j);
            indices.push_back(j + 1);
            indices.push_back(j + 3);

            indices.push_back(j);
            indices.push_back(j + 3);
            indices.push_back(j + 2);
        }
        a += step;
    }
}

// vertex contains position, normals and UV
struct vertex
{
    glm::vec3 v;
    glm::vec3 n;
    glm::vec2 t;

    vertex() {}

    vertex(glm::vec3& v, glm::vec3& n, glm::vec2& t)
    {
        this->v = v;
        this->n = n;
        this->t = t;
    }
};

// vertex shader
const GLchar* vertexShaderSource = GLSL(330,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal;  // normal coordinates (**)
    layout(location = 2) in vec2 tex;  // texture coordinates

    out vec2 texCoord;
    out vec3 vertexNormal; // For outgoing normals to fragment shader (**)
    out vec3 vertexFragmentPos;// 3D interpolated position per fragment

    //Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;


    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
        texCoord = tex; // output texture coordinate))
        vertexNormal = mat3(transpose(inverse(model))) * normal;// output normal
        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // output fragment pos
    }
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(330,
    // From raster interpolation
    in vec2 texCoord;
    in vec3 vertexNormal; 
    in vec3 vertexFragmentPos; 

    // uniform variables
    uniform vec3 lightColor1; // first light color
    uniform vec3 lightPos1;   // first light pos
    uniform vec3 lightColor2; // second light color
    uniform vec3 lightPos2;   // second light pos
    uniform sampler2D uTexture; // diffuse texture
    uniform vec3 viewPosition; // fixed view position
    uniform float transparency;// fragment transparency

    out vec4 fragmentColor;     // the output of fragment shader

    void main()
    {

        float ambientStrength = 0.1f; // Set ambient or global lighting strength
        vec3 ambient = ambientStrength * (lightColor1 + lightColor2); // Generate ambient light color

        vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit

        // Calculate Diffuse lighting
        vec3 lightDirection1 = normalize(lightPos1 - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        float impact = abs(dot(norm, lightDirection1));// Calculate diffuse impact by generating dot product of normal and light
        vec3 diffuse = impact * lightColor1; // Generate diffuse light color
        vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        impact = abs(dot(norm, lightDirection2));// Calculate diffuse impact by generating dot product of normal and light
        diffuse += impact * lightColor2; // Generate diffuse light color

        float specularIntensity = 0.8f; // Set specular light strength
        float highlightSize = 16.0f; // Set specular highlight size
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction

        // calculate specular for 2 lights
        vec3 reflectDir = reflect(-lightDirection1, norm);// Calculate reflection vector
        float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        vec3 specular = specularIntensity * specularComponent * lightColor1;

        reflectDir = reflect(-lightDirection2, norm);// Calculate reflection vector
        specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        specular += specularIntensity * specularComponent * lightColor2;

        vec4 color = texture(uTexture, texCoord);
        vec3 phong = (ambient + diffuse + specular) * color.xyz;
        fragmentColor = vec4(phong, transparency); // Send lighting results to GPU

    }
);


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateCylinder(gMesh); // create cylinder
    UCreateCube(gMesh2);    // cube (user for table and floor)
    UCreateVase(gMesh3);    // vase 

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // black background
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // update light angle
        gAngle += gDeltaTime;
        if (gAngle > 2.0f * 3.14159f)
            gAngle -= 2.0f * 3.14159f;


        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;


    /////////////////////////////////
    //
    //  LOADING ALL TEXTURES
    //
    /////////////////////////////////


    if (!UCreateTexture("images/wood.jpg", gTextureId)) // (**)
    {
        cout << "Failed to load texture " << "images/wood.jpg" << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture("images/jar.jpg", gTextureId2)) // (**)
    {
        cout << "Failed to load texture " << "images/jar.jpg" << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture("images/floor.jpg", gTextureId3)) // (**)
    {
        cout << "Failed to load texture " << "images/floor.jpg" << endl;
        return EXIT_FAILURE;
    }

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) // (**)
        gCamera.ProcessKeyboard(Q_DIR, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) // (**)
        gCamera.ProcessKeyboard(E_DIR, gDeltaTime);
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    // computing movement offset
    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    // updating last mouse position
    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
        case GLFW_MOUSE_BUTTON_LEFT:
        {
            if (action == GLFW_PRESS)
                cout << "Left mouse button pressed" << endl;
            else
                cout << "Left mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_MIDDLE:
        {
            if (action == GLFW_PRESS)
                cout << "Middle mouse button pressed" << endl;
            else
                cout << "Middle mouse button released" << endl;
        }
        break;

        case GLFW_MOUSE_BUTTON_RIGHT:
        {
            if (action == GLFW_PRESS)
                cout << "Right mouse button pressed" << endl;
            else
                cout << "Right mouse button released" << endl;
        }
        break;

        default:
            cout << "Unhandled mouse button event" << endl;
            break;
    }
}


// Function called to render a frame
void URender()  // (**)
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    
    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Set the shader to be used
    glUseProgram(gProgramId);

    // taking all locations
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");
    GLint texLoc = glGetUniformLocation(gProgramId, "uTexture");
    GLint lightColorLoc1 = glGetUniformLocation(gProgramId, "lightColor1");// (**)
    GLint lightPositionLoc1 = glGetUniformLocation(gProgramId, "lightPos1");// (**)
    GLint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");// (**)
    GLint lightPositionLoc2 = glGetUniformLocation(gProgramId, "lightPos2");// (**)
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");// (**)
    GLint transparencyLoc = glGetUniformLocation(gProgramId, "transparency");// (**)

    // setting up light colors
    glUniform3f(lightColorLoc1, gLightColor1.r, gLightColor1.g, gLightColor1.b);// (**)
    glUniform3f(lightColorLoc2, gLightColor2.r, gLightColor2.g, gLightColor2.b);// (**)

    // setting up light positions, they rotate around Y axis in opposite directions
    glm::mat4 rot1 = glm::rotate(glm::mat4(1.0f), gAngle, glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rot2 = glm::rotate(glm::mat4(1.0f),-gAngle, glm::vec3(0.0f, 1.0f, 0.0f));
    glm::vec4 L = rot1 * gLightPosition1;
    glUniform3f(lightPositionLoc1, L.x, L.y, L.z);// first light rotated
    L = rot2 * gLightPosition2;
    glUniform3f(lightPositionLoc2, L.x, L.y, L.z);// second light rotated

    // send view position into shader
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);// (**)

    // send view and projection
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // texture location is always 0, I use 1 texture per object
    glUniform1i(texLoc, 0);


    ////////////////////////////////////////
    ////////////////////////////////////////
    // RENDER OBJECTS BELOW THE FLOOR
    ////////////////////////////////////////
    ////////////////////////////////////////

    // TABLE LEGS
    glBindVertexArray(gMesh.vao);

    // activating texture
    glActiveTexture(GL_TEXTURE0); // (**)
    glBindTexture(GL_TEXTURE_2D, gTextureId); // (**)

    // set opaque
    glUniform1f(transparencyLoc, 1.0f);

    // 1. Scales the CUBE
    glm::mat4 scale = glm::scale(glm::vec3(0.2f,1.0f, 0.2f));

    // 2. render each leg of the table
    float delta = 0.5f;
    for (float dx = -delta; dx <= delta; dx += 2* delta) for (float dz = -delta; dz <= delta; dz += 2* delta)
    {
        // translating cylinder
        glm::mat4 T = glm::translate(glm::vec3(dx, 0.5f, dz));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::scale(glm::vec3(1.0f, -1.0f, 1.0f)) * T * scale;
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle
    }


    // drawing the top of the table
    glBindVertexArray(gMesh2.vao);
    glm::mat4 model = glm::scale(glm::vec3(1.0f, -1.0f, 1.0f)) * glm::translate(glm::vec3(0.0f, 1.0f, 0.0f)) * glm::scale(glm::vec3(0.75f, 0.125f, 0.75f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // drawing the VASE
    glBindVertexArray(gMesh3.vao);
    model = glm::scale(glm::vec3(1.0f, -1.0f, 1.0f)) * glm::translate(glm::vec3(0.0f, 1.4f, 0.0f)) * glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gTextureId2); // (**)
    glDrawElements(GL_TRIANGLES, gMesh3.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle



    ////////////////////////////////////////
    ////////////////////////////////////////
    // RENDER SEMI TRANSPARENT FLOOR
    ////////////////////////////////////////
    ////////////////////////////////////////

    glBindVertexArray(gMesh2.vao);
    // set semi transparent floor
    glUniform1f(transparencyLoc, 0.8f);
    // turn blending ON
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // floor texture
    glBindTexture(GL_TEXTURE_2D, gTextureId3); 
    model = glm::translate(glm::vec3(0.0f, -0.1f, 0.0f)) * glm::scale(glm::vec3(5.0f, 0.05f, 5.0f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    // drawing scaled cube
    glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle
    // turn blending OFF
    glDisable(GL_BLEND);


    ////////////////////////////////////////
    ////////////////////////////////////////
    // RENDER OBJECTS ABOVE THE FLOOR
    ////////////////////////////////////////
    ////////////////////////////////////////


    // set opaque
    glUniform1f(transparencyLoc, 1.0f);

    // CYLINDER (table legs)
    glBindVertexArray(gMesh.vao);

    // activating texture
    glActiveTexture(GL_TEXTURE0); // (**)
    glBindTexture(GL_TEXTURE_2D, gTextureId); // (**)


    // 1. Scales the object by 2
    scale = glm::scale(glm::vec3(0.2f, 1.0f, 0.2f));
    // 2. Rotates shape by 15 degrees in the x axis

    delta = 0.5f;
    for (float dx = -delta; dx <= delta; dx += 2 * delta) for (float dz = -delta; dz <= delta; dz += 2 * delta)
    {
        // translating cylinder
        glm::mat4 T = glm::translate(glm::vec3(dx, 0.5f, dz));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = T * scale;
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle
    }

    // table TOP
    glBindVertexArray(gMesh2.vao);
    model = glm::translate(glm::vec3(0.0f, 1.0f, 0.0f)) * glm::scale(glm::vec3(0.75f, 0.125f, 0.75f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // VASE
    glBindVertexArray(gMesh3.vao);
    model = glm::translate(glm::vec3(0.0f, 1.4f, 0.0f)) * glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gTextureId2); // (**)
    glDrawElements(GL_TRIANGLES, gMesh3.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle


    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateCylinder(GLMesh &mesh)
{
    vector<glm::vec3> verts;
    vector<glm::vec3> norms;
    vector<glm::vec2> uv;
    vector<unsigned short> indices;


    CreateCylinder(20,
        1,
        0.5f,
        1.0f,
        verts,
        norms,
        uv,
        indices);

    // groping position, normals and UVs into a single vector
    vector <vertex> data;
    for (int i = 0; i < verts.size(); i++)
    {
        data.push_back(vertex(verts[i], norms[i], uv[i]));
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float) * 8, data.data(), GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbo[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned short) * indices.size(), indices.data(), GL_STATIC_DRAW);

    // Strides between vertex coordinates is 8 (x, y, z, r, g, b, u, v). A tightly packed stride is 0.
    GLint stride = sizeof(float) * 8;// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}

// Implements the UCreateMesh function
void UCreateVase(GLMesh& mesh)
{
    vector<glm::vec3> verts;
    vector<glm::vec3> norms;
    vector<glm::vec2> uv;
    vector<unsigned short> indices;

    // creating the silhouoette "hand made"
    verts.push_back(glm::vec3(0.0f, -3.0f, 0.0f));
    verts.push_back(glm::vec3(1.0f, -3.0f, 0.0f));
    verts.push_back(glm::vec3(2.5f, -1.5f, 0.0f));
    verts.push_back(glm::vec3(3.0f, -0.5f, 0.0f));
    verts.push_back(glm::vec3(2.5f,  0.5f, 0.0f));
    verts.push_back(glm::vec3(1.5f,  1.5f, 0.0f));
    verts.push_back(glm::vec3(1.0f,  2.5f, 0.0f));
    verts.push_back(glm::vec3(1.5f,  3.5f, 0.0f));
    verts.push_back(glm::vec3(0.0f,  3.5f, 0.0f));

    norms.push_back(glm::vec3(0.0f, -1.0f, 0.0f));
    norms.push_back(glm::vec3(0.2f, -0.8f, 0.0f)); norms[1] = glm::normalize(norms[1]);
    norms.push_back(glm::vec3(0.5f, -0.5f, 0.0f)); norms[2] = glm::normalize(norms[2]);
    norms.push_back(glm::vec3(1.0f,  0.0f, 0.0f)); 
    norms.push_back(glm::vec3(0.5f,  0.5f, 0.0f)); norms[4] = glm::normalize(norms[4]);
    norms.push_back(glm::vec3(0.25f, 0.75f, 0.0f)); norms[5] = glm::normalize(norms[5]);
    norms.push_back(glm::vec3(1.0f,  0.0f, 0.0f)); 
    norms.push_back(glm::vec3(0.25f,-0.75f, 0.0f)); norms[7] = glm::normalize(norms[7]);
    norms.push_back(glm::vec3(0.0f,  1.0f, 0.0f)); 

    uv.push_back(glm::vec2(0.0f, 0.0f));
    uv.push_back(glm::vec2(1.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(2.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(3.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(4.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(5.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(6.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(7.0f / 8.0f, 0.0f));
    uv.push_back(glm::vec2(8.0f / 8.0f, 0.0f));

    // rotating the points of the silhouette
    for (float a = 10.0f; a <= 361.0f; a += 10.0f)
    {
        glm::mat4 r(1.0f);
        r = glm::rotate(glm::radians(a), glm::vec3(0.0f, 1.0f, 0.0f));
        for (int i = 0; i < 9; i++)
        {
            verts.push_back(glm::vec3(r * glm::vec4(verts[i], 1.0f)));
            norms.push_back(glm::vec3(r * glm::vec4(norms[i], 0.0f)));
            uv.push_back(glm::vec2(uv[i].x, a / 360.0f));
        }
    }

    // creating indices
    for (int j=0; j<36; j++)
        for (int i = 0; i < 8; i++)
        {
            indices.push_back(j * 9 + i);
            indices.push_back((j + 1) * 9 + i);
            indices.push_back((j + 1) * 9 + i+1);

            indices.push_back(j * 9 + i);
            indices.push_back((j + 1) * 9 + i + 1);
            indices.push_back(j * 9 + i + 1);
        }


    // groping into a single vector od data
    vector <vertex> data;
    for (int i = 0; i < verts.size(); i++)
        data.push_back(vertex(verts[i], norms[i], uv[i]));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float) * 8, data.data(), GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbo[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned short) * indices.size(), indices.data(), GL_STATIC_DRAW);

    // Strides between vertex coordinates is 8 (x, y, z, r, g, b, u, v). A tightly packed stride is 0.
    GLint stride = sizeof(float) * 8;// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}


// Implements the UCreateMesh function
void UCreateCube(GLMesh& mesh)
{
    vector<glm::vec3> verts =
    {

        // Front Face
        glm::vec3(-1.0f, -1.0f, -1.0f),
        glm::vec3(-1.0f,  1.0f, -1.0f),
        glm::vec3(1.0f,  1.0f, -1.0f),
        glm::vec3(1.0f, -1.0f, -1.0f),

        // Back Face
        glm::vec3(-1.0f, -1.0f, 1.0f),
        glm::vec3(1.0f, -1.0f, 1.0f),
        glm::vec3(1.0f,  1.0f, 1.0f),
        glm::vec3(-1.0f,  1.0f, 1.0f),

        // Top Face
        glm::vec3(-1.0f, 1.0f, -1.0f),
        glm::vec3(-1.0f, 1.0f,  1.0f),
        glm::vec3(1.0f, 1.0f,  1.0f),
        glm::vec3(1.0f, 1.0f, -1.0f),

        // Bottom Face
        glm::vec3(-1.0f, -1.0f, -1.0f),
        glm::vec3(1.0f, -1.0f, -1.0f),
        glm::vec3(1.0f, -1.0f,  1.0f),
        glm::vec3(-1.0f, -1.0f,  1.0f),

        // Left Face
        glm::vec3(-1.0f, -1.0f,  1.0f),
        glm::vec3(-1.0f,  1.0f,  1.0f),
        glm::vec3(-1.0f,  1.0f, -1.0f),
        glm::vec3(-1.0f, -1.0f, -1.0f),

        // Right Face
        glm::vec3(1.0f, -1.0f, -1.0f),
        glm::vec3(1.0f,  1.0f, -1.0f),
        glm::vec3(1.0f,  1.0f,  1.0f),
        glm::vec3(1.0f, -1.0f,  1.0f),
    };

    vector<glm::vec2> uvs = 
    {
        // Front Face
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 1.0f),

        // Back Face
        glm::vec2(1.0f, 1.0f),
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),

        // Top Face
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 1.0f),

        // Bottom Face
        glm::vec2(1.0f, 1.0f),
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),

        // Left Face
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 1.0f),

        // Right Face
        glm::vec2(0.0f, 1.0f),
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 1.0f),

    };

    vector<glm::vec3> norms =
    {
        // Front Face
        glm::vec3(0.0f, 0.0f, 1.0f),
        glm::vec3(0.0f, 0.0f, 1.0f),
        glm::vec3(0.0f, 0.0f, 1.0f),
        glm::vec3(0.0f, 0.0f, 1.0f),

        // Back Face
        glm::vec3(0.0f, 0.0f, -1.0f),
        glm::vec3(0.0f, 0.0f, -1.0f),
        glm::vec3(0.0f, 0.0f, -1.0f),
        glm::vec3(0.0f, 0.0f, -1.0f),

        // Top Face
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),

        // Bottom Face
        glm::vec3(0.0f, -1.0f, 0.0f),
        glm::vec3(0.0f, -1.0f, 0.0f),
        glm::vec3(0.0f, -1.0f, 0.0f),
        glm::vec3(0.0f, -1.0f, 0.0f),

        // Left Face
        glm::vec3(-1.0f, 0.0f, 0.0f),
        glm::vec3(-1.0f, 0.0f, 0.0f),
        glm::vec3(-1.0f, 0.0f, 0.0f),
        glm::vec3(-1.0f, 0.0f, 0.0f),

        // Right Face
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(1.0f, 0.0f, 0.0f),
    };

    vector<unsigned short> indices =
    {
        // Front Face
        0,  2,  1,
        0,  3,  2,

        // Back Face
        4,  6,  5,
        4,  7,  6,

        // Top Face
        8,  10, 9,
        8, 11, 10,

        // Bottom Face
        12, 14, 13,
        12, 15, 14,

        // Left Face
        16, 17, 18,
        16, 18, 19,

        // Right Face
        20, 21, 22,
        20, 22, 23
    };


    // groping all together (pos + normals + UVs)
    vector <vertex> data;
    for (int i = 0; i < verts.size(); i++)
    {
        data.push_back(vertex(verts[i], norms[i], uvs[i]));
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, data.size() * sizeof(float) * 8, data.data(), GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = indices.size();
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbo[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned short) * indices.size(), indices.data(), GL_STATIC_DRAW);

    // Strides between vertex coordinates is 8 (x, y, z, r, g, b, u, v). A tightly packed stride is 0.
    GLint stride = sizeof(float) * 8;// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * 6));
    glEnableVertexAttribArray(2);
}



void UDestroyMesh(GLMesh &mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbo);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint &programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
